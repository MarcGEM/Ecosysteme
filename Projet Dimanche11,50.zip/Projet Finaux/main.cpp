#include "grman/grman.h"
#include <iostream>

#include "graph.h"
#include <string>
#include <stack>
using namespace std;

bool connexite(std::string oceanmat)
{
    std::ifstream fichier(oceanmat, std::ios::in);
    int ordre;
    fichier >> ordre; /// ordre prend le nombre de sommet
    int som=0;
    int verif=0;
    std::vector<bool> connexe;
    std::stack<int> pile;
    pile.push(som);

    for(int i=0; i<ordre; i++)  /// On rajoute le nb de cases de sommet et on met � faux
        connexe.push_back(false);


    int matrice_adj[ordre][ordre];

    for(int i=0; i<ordre; i++)
    {
        for(int j=0; j<ordre; j++)
            fichier >> matrice_adj[i][j];
    }

    while(!pile.empty())
    {
        som=pile.top();
        pile.pop();
        connexe[som]=true;
        for(int i=0; i<ordre; i++)
        {
            if(matrice_adj[som][i]==1 && connexe[i]==false)
            {
                pile.push(i);
                connexe[i]=true;
            }
        }
    }

    for(int i=0; i<connexe.size(); i++)
    {
        if(connexe[i]==false)
            verif++;
    }

    if(verif!=0)
        return 0;
    else
        return 1;
}

int main()
{


    Graph mongraphe2;

    srand(time(NULL));


    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");



    BITMAP *rougee= NULL;
    BITMAP *buffer = NULL;
    BITMAP* menu = NULL;
    buffer = create_bitmap(SCREEN_W,SCREEN_H);
    menu = load_bitmap("menu.bmp",NULL);
    rougee = load_bitmap("rouge.jpg",NULL);
    BITMAP* choix = NULL;
    choix = load_bitmap("choix3.jpg",NULL);

    int x=1;
    int choi =0;
    int a=-1;
    int i=0, j=0;



    //mongraphe2.make_example(choi);

    while ( !key[KEY_ESC] )
    {
        masked_blit(menu, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);


        // if(mouse_x >= 340 && mouse_x <= 700 && mouse_y>=30 &&  mouse_y <= 400 && mouse_b & 1)
        if(mouse_x>=48 && mouse_x <= 221+48 && mouse_y>=610 &&  mouse_y <= 610+76 && mouse_b & 1 )
        {

            while ( !key[KEY_ESC] )
            {
                masked_blit(choix, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                if(mouse_x >= 30 && mouse_x <= 300 && mouse_y>= 100 &&  mouse_y <= 600 && mouse_b & 1)
                {
                    while ( !key[KEY_ESC] )
                    {
                        // rectfill(choix, 600, 500, 400, 800, makecol(255,0,0));
                        masked_blit(choix, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

                        if(mouse_x >= 70 && mouse_x <= 30+200 && mouse_y>=130 &&  mouse_y <=130+200 && mouse_b & 1)
                        {
                            choi=1;
                            mongraphe2.make_example(choi);


                            while ( !key[KEY_ESC] )
                            {

                                mongraphe2.test_population();

                                // masked_blit(rougee, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                                //masked_blit(rougee, screen, 0, 0, 900, 0, SCREEN_W, SCREEN_H);
                                if(mouse_b & 2)
                                {
                                    std::cout << "quelle arrete voulais vous supprimer?" << std::endl;
                                    std::cin >> i;

                                    mongraphe2.test_remove_edge(i);
                                }
                                if(mouse_b & 2 && a != j)
                                {
                                    //    for(int i=0; i<)
                                    //  mongraphe2.test_remove_edge(i);
                                    j++, a = j;
                                }
                                if(a == j && mouse_b == 0)
                                    a = 0;

                                mongraphe2.update();
                                mongraphe2.create(choi);
                                mongraphe2.Aretecreer();
                                mongraphe2.supprimer();

                                grman::mettre_a_jour();

                                if(mouse_x>= 700 && mouse_y >= 500 && mouse_b & 1)
                                {
                                    if(connexite("oceanmat.txt")==true)
                                    {
                                        std::cout << "vous avez une connexit� " << std::endl;
                                    }
                                    else(connexite("oceanmat.txt")==false);
                                    {
                                        std::cout << "vous n'avez pas de connexit�" << std::endl;
                                    }
                                }


                            }

                        }
                    }
                }


                if(mouse_x >= 415 && mouse_x <= 415+256 && mouse_y>=300 &&  mouse_y <= 300+200 && mouse_b & 1)
                {
                    choi=2;
                    mongraphe2.make_example(choi);

                    while ( !key[KEY_ESC] )
                    {

                        mongraphe2.test_population();
                        if(mouse_b & 2)
                        {
                            std::cout << "quelle arrete voulais vous supprimer?" << std::endl;
                            std::cin >> i;

                            mongraphe2.test_remove_edge(i);
                        }
                        if(mouse_b & 2 && a != j)
                        {

                            j++, a = j;
                        }

                        if(a == j && mouse_b == 0)
                            a = 0;

                        mongraphe2.update();
                        mongraphe2.create(choi);
                        mongraphe2.Aretecreer();
                        mongraphe2.supprimer();
                        grman::mettre_a_jour();

                    }
                }

                if(mouse_x >= 745 && mouse_x <= 745+260 && mouse_y> 147 &&  mouse_y <= 147+188&& mouse_b & 1)
                {
                    choi=3;
                    mongraphe2.make_example(choi);
                    while ( !key[KEY_ESC] )
                    {
                        //choi = 2;
                        // masked_blit(rougee, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                        //masked_blit(rougee, screen, 0, 0, 900, 0, SCREEN_W, SCREEN_H);
                        if(mouse_b & 2)
                        {
                            std::cout << "quelle arrete voulais vous supprimer?" << std::endl;
                            std::cin >> i;

                            mongraphe2.test_remove_edge(i);
                        }
                        if(mouse_b & 2 && a != j)
                        {

                            j++, a = j;
                        }

                        if(a == j && mouse_b == 0)
                            a = 0;

                        mongraphe2.update();
                        mongraphe2.create(choi);
                        mongraphe2.Aretecreer();
                        mongraphe2.supprimer();
                        grman::mettre_a_jour();

                    }
                }


            }
        }


        //mongraphe2.sauvegarde(choi);
    }
    mongraphe2.sauvegardeponderer(choi);
    mongraphe2.sauvegarde(choi);

    grman::fermer_allegro();

main();
    return 0;
}
END_OF_MAIN();

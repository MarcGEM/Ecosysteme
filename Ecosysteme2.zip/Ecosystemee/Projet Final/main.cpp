#include "grman/grman.h"
#include <iostream>

#include "graph.h"

int main()
{
 /*   std::string fichierprim;
    std::string fichierdijkstra;*/

    Graph mongraphe;
    Graph mongraphe2;

    srand(time(NULL));




    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");

    /// Un exemple de graphe
    //Graph g;
    //g.make_example();


    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )

    BITMAP *rougee= NULL;
    BITMAP *buffer = NULL;
    BITMAP* menu = NULL;
    buffer = create_bitmap(SCREEN_W,SCREEN_H);
    menu = load_bitmap("menu.bmp",NULL);
    rougee = load_bitmap("rouge.jpg",NULL);
    BITMAP* choix = NULL;
    choix = load_bitmap("choix3.jpg",NULL);


    mongraphe2.make_example();
    int x=1;
    int choi =0;
    while ( !key[KEY_ESC] )
    {
while(x=1) /// Boucle d'interaction
    {
          masked_blit(menu, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      //  rectfill(screen, 0, 0, 40, 40, makecol(255,0,0)); /// Dessiner un rectangle
       // rectfill(menu, 700, 340, 400, 400, makecol(255,0,0));

//                if(mouse_x <40 && mouse_y < 40 && mouse_b & 1)
//                  exit(0);

          if( mouse_x>=340 && mouse_x <= 700 && mouse_y>=30 &&  mouse_y <= 400 && mouse_b & 1)
        {
            while ( !key[KEY_ESC] )
    {
        //rectfill(choix, 20, 340, 400, 800, makecol(255,0,0));
            masked_blit(choix, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
            if(mouse_x >= 30 && mouse_x <= 300 && mouse_y>=100 &&  mouse_y <= 600 && mouse_b & 1)
            {
        while ( !key[KEY_ESC] )
    {
        choi = 1;
       // masked_blit(rougee, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
        //masked_blit(rougee, screen, 0, 0, 900, 0, SCREEN_W, SCREEN_H);

        mongraphe2.update();
        mongraphe2.create();
        mongraphe2.Aretecreer();

        grman::mettre_a_jour();

        }
            }
      }
        }
    }
}

    //mongraphe2.WriteOnFile("unfichier.txt");
    grman::fermer_allegro();


    return 0;
}
END_OF_MAIN();
